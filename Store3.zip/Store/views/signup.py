from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.views import View
from Store.models.customer import Customer


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        repassword = postData.get('repassword')
        value = {'firstname': firstname, 'lastname': lastname, 'phone': phone, 'email': email}
        customer = Customer(firstname=firstname, lastname=lastname, phone=phone, email=email, password=password)

        error_message = None
        if not firstname:
            error_message = "First name required"
        elif not lastname:
            error_message = "Last name required"
        elif not email:
            error_message = "Email required"
        elif not password:
            error_message = "Password required"
        elif len(password) < 6:
            error_message = "Password must be 6 or more characters long"
        elif customer.isExist():
            error_message = "Email address already exists.."
        elif not repassword:
            error_message = "Password must be reentered"
        elif repassword != password:
            error_message = "Password must be same"

        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('Home')
        else:
            return render(request, 'signup.html', {'error': error_message, 'values': value})
