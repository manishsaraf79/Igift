from django.shortcuts import render, redirect, HttpResponseRedirect, get_object_or_404
from django.db.models import Avg
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from Store.models.category import Category
from Store.models.product import Product, Postimage
from Store.models.subcategory import Subcategory
from Store.models.review import Review
from Store.models.customer import Customer
from django.views import View


class Showproducts(View):

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        prods = None
        categoryID = request.GET.get('category')
        subcategoryID = request.GET.get('subcategory')
        subcategory = Product.get_subcategories_bycateid(categoryID)
        subcategoryname = Subcategory.get_subcategories_byids(subcategory)
        query = request.GET.get('q')
        if query:
            prods = Product.objects.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(detail__icontains=query))
            paginator = Paginator(prods, 12)
            page = request.GET.get('page')
            try:
                items = paginator.page(page)
            except PageNotAnInteger:
                items = paginator.page(1)
            except EmptyPage:
                items = paginator.page(paginator.num_pages)
            if prods:
                params = {'items': items, 'query': query}
                return render(request, 'product.html', params)
            if not prods:
                error_msg = "No products to show"
                params = {'products': prods, 'error': error_msg}
                return render(request, 'product.html', params)

        if categoryID:
            prods = Product.get_all_products_byid(categoryID)
            if not prods:
                items = prods
                error_msg = "No products to show"
                params = {'items': items, 'error': error_msg}
                return render(request, 'product.html', params)

        if categoryID and subcategoryID:
            prods = Product.objects.filter(category_id=categoryID, subcategory_id=subcategoryID)

        if not categoryID:
            prods = Product.get_all_products()

        paginator = Paginator(prods, 12)
        page = request.GET.get('page')
        try:
            items = paginator.page(page)
        except PageNotAnInteger:
            items = paginator.page(1)
        except EmptyPage:
            items = paginator.page(paginator.num_pages)

        params = {'items': items, 'categoryID': categoryID, 'subcategory': subcategoryname, 'category': categoryID}
        return render(request, 'product.html', params)


class ProductDetail(View):
    def get(self, request):
        global params
        global prod
        global reviews
        global categoryprod
        global category
        global average
        global postimages
        productID = request.GET.get('id')
        reviews = Review.get_all_reviews_byid(id=productID)
        ratings = Review.get_all_reviews_byid(id=productID).aggregate(Avg('rating'))["rating__avg"]
        postSKU = Product.objects.get(id=productID).SKU
        average = "Not yet Rated"
        if ratings:
            average = round(ratings, 2)
        prod = get_object_or_404(Product, id=productID)
        categoryid = prod.category_id
        category = Category.objects.get(id=categoryid)
        categoryprod = Product.get_all_products_byid(categoryid)
        #postimages = Postimage.get_all_images_byid(productID)
        postimages = Postimage.objects.filter(SKU=postSKU)
        params = {'product': prod, 'reviews': reviews, 'categoryprods': categoryprod, 'category': category,
                  'average': average, 'postimages': postimages}
        return render(request, 'productdetail.html', params)

    def post(self, request):

        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        productID = request.GET.get('id')
        getid = request.POST.get('getid')

        if getid:
            error_message = None
            email = request.session.get('email')
            customer = Customer.get_customer_by_email(email).firstname
            review = request.POST.get('review')
            rating = request.POST.get('rating')
            if not review:
                error_message = "Please enter your review"
                params = {'product': prod, 'reviews': reviews, 'categoryprods': categoryprod, 'category': category,
                          'average': average, 'postimages': postimages, 'errorrev': error_message}
                return render(request, 'productdetail.html', params)
            if not rating:
                error_message = "Please enter rating"
                params = {'product': prod, 'reviews': reviews, 'categoryprods': categoryprod, 'category': category,
                          'average': average, 'postimages': postimages, 'errorrev': error_message}
                return render(request, 'productdetail.html', params)
            if review and rating:
                addreviews = Review(product=productID,
                                    customername=customer,
                                    reviews=review,
                                    rating=rating)
                addreviews.addReview()

        elif cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        params = {'product': prod, 'reviews': reviews, 'categoryprods': categoryprod, 'category': category,
                  'average': average, 'postimages': postimages}
        return render(request, 'productdetail.html', params)