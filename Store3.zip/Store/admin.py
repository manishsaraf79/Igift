from django.contrib import admin
from Store.models.product import Product
from Store.models.category import Category
from Store.models.subcategory import Subcategory
from Store.models.customer import Customer
from Store.models.orders import Order
from Store.models.states import State
from Store.models.review import Review
from Store.models.carouselimage import Carouselimage
from Store.models.product import Postimage

class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'photos', 'size', 'SKU','category', 'subcategory', 'description', 'detail', 'image', 'new']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminState(admin.ModelAdmin):
    list_display = ['name']

class AdminCarouselimage(admin.ModelAdmin):
    list_display = ['image']

class AdminReview(admin.ModelAdmin):
    list_display = ['customername', 'reviews']

class AdminPostimage(admin.ModelAdmin):
    list_display = ['product', 'productimage', 'SKU']

# Register your models here.
admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Subcategory)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(Review, AdminReview)
admin.site.register(State, AdminState)
admin.site.register(Carouselimage, AdminCarouselimage)
admin.site.register(Postimage, AdminPostimage)
