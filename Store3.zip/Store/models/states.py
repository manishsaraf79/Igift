from django.db import models

class State(models.Model):
    name = models.CharField(max_length=50)

    @staticmethod
    def get_all_states():
        return State.objects.all()