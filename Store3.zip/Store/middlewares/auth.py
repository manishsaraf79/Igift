from django.shortcuts import render, redirect
from Store.models.category import Category

def auth_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
           #returnUrl = request.META['PATH_INFO']
           #if not request.session.get('customer'):
           #    return redirect(f'login?return_url=/cart')
           categos = Category.get_all_products()
           return render(request, {'categories': categos})
           #response = get_response(request)
           #return response

    return middleware