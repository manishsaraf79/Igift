from django.db import models

class Review(models.Model):
    product = models.IntegerField()
    customername = models.CharField(max_length=50)
    reviews = models.TextField(blank=True, max_length=2000)
    rating = models.IntegerField(blank=True, default=3)

    def addReview(self):
        self.save()

    @staticmethod
    def get_all_reviews_byid(id):
        return Review.objects.filter(product=id)