from django.db import models
from .category import Category
from .subcategory import Subcategory


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.IntegerField(default=999)
    photos = models.IntegerField(default=20)
    size = models.CharField(max_length=100, default="", blank=True)
    SKU = models.CharField(max_length=50, default="", blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    subcategory = models.ForeignKey(Subcategory, on_delete=models.CASCADE, null=True, blank=True)
    description = models.CharField(max_length=200, default="", blank=True)
    detail = models.CharField(max_length=5000, default="", blank=True)
    image = models.ImageField(upload_to='uploads/products/')
    new = models.BooleanField(default=False)

    @staticmethod
    def get_cartproducts_by_id(ids):
        return Product.objects.filter(id__in=ids)

    @staticmethod
    def get_savedproducts_by_id(ids):
        return Product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Product.objects.all().order_by('price')

    @staticmethod
    def get_all_products_byid(categoryid):
        if categoryid:
            return Product.objects.filter(category=categoryid)

    @staticmethod
    def get_all_products_byidsub(categoryid):
        if categoryid:
            return Product.objects.filter(category=categoryid)

    def get_subcategories_bycateid(categoryid):
        return Product.objects.filter(category=categoryid).values('subcategory').distinct()

class Postimage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    productimage = models.FileField(upload_to='uploads/products')
    type = models.CharField(max_length=20, default='image')

    def get_all_images_byid(productid):
        if productid:
          return Postimage.objects.filter(product=productid)